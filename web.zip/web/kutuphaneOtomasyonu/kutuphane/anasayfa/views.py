from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

def anasayfa(request):
    return HttpResponse("Anasayfa")

def anasayfa(request):
  template = loader.get_template('anasayfa.html')
  return HttpResponse(template.render())

# Create your views here.
