from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

# def kitaplar(request):
#     return HttpResponse("Anasayfa")

# def kitaplar(request): # burası liste göndermiyor şuan.
#   template = loader.get_template('kitaplar.html')
#   return HttpResponse(template.render())

# # Create your views here.
# bu bilgileri nereden alıyor

from .models import Kitaplar

def kitaplar(request):
    kitapliste = Kitaplar.objects.all()
    template = loader.get_template('kitaplar.html')
    context ={
        'kitapliste' : kitapliste,
    }
    return HttpResponse(template.render(context, request))

def detay(request, id):
  item = Kitaplar.objects.get(kn=id)
  template = loader.get_template('detay.html')
  context = {
    'item': item,
  }
  return HttpResponse(template.render(context, request))

from django.shortcuts import redirect
from django import forms
from .models import Kitaplar
class KitapForm(forms.ModelForm):
    class Meta:
        model = Kitaplar
        fields = ['kn', 'kitapadi',
                  'tur','yazar']  


def ekle(request):
    if request.method == 'POST':
        form = KitapForm(request.POST)
        if form.is_valid():
            # Form verileri işleme
            form.save()  # Veritabanına kaydetme
            return redirect('kitaplar')  #url name
    else:
        form = KitapForm()
    return render(request, 'ekle.html', {'form': form})
# geçen arkadaş için hastaneye gitmiştik ya. Parmağı kopmuş malesef.. :( hocam çok geçmiş olsun başka yerinde bir şey yoktur inşallah motorsikleti temizlerken olmuş. ben de trafik kazası sanmıştım. çok geçmiş olsun

from django.shortcuts import get_object_or_404

def guncelle(request, id):
  kitap = get_object_or_404(Kitaplar, kn=id)
  # kitap = Ogrenci.objects.get(id=id)
  if request.method == 'POST':
      form = KitapForm(request.POST, instance=kitap)
      if form.is_valid():
          # Form verileri işleme
          form.save()  # Veritab. kaydetme
          return redirect('kitaplar') #url name
  else:
      form = KitapForm(instance=kitap)
  return render(request, 'guncelle.html', {'form': form})
  
  
def sil(request, id):
    item = Kitaplar.objects.get(kn=id)
    item.delete()
    return redirect('kitaplar')  #url name
