from django.db import models

class Kitaplar(models.Model): # sınıfların adı normalde tekil olması gerek.. ama önemli değil.
  kn = models.CharField(max_length=11)
  kitapadi = models.CharField(max_length=50)
  tur = models.CharField(max_length=255)
  yazar = models.CharField(max_length=255)
  resimadresi = models.CharField(max_length=255, null=True)
  kitapAciklamasi = models.CharField(max_length=255, null=True)

