from django.urls import path
from . import views

urlpatterns = [
    path('kitaplar/', views.kitaplar, name='kitaplar'),
    path('kitaplar/detay/<int:id>', views.detay, name='detay'),
    path('kitaplar/ekle/', views.ekle, name='ekle'),
    path('kitaplar/guncelle/<int:id>', views.guncelle, name='guncelle'),
    path('kitaplar/sil/<int:id>', views.sil, name='sil'),
]

