from django.http import HttpResponse
from django.template import loader


def ogretmen(request):
    template = loader.get_template('kitaplar.html')
    return HttpResponse(template.render())